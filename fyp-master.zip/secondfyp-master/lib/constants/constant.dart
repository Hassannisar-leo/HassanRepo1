import 'package:flutter/material.dart';

class AppColors {
  static const Color blue = Color(0xFF1A76A3);
  static const Color lightBlue = Color(0xFFC2E7F9);
  static const Color grey = Color(0xFFBEC1C2);
  static const Color darkGrey = Color(0xFF101828);
  static const Color anotherDarkGrey = Color(0xFF101828);
}